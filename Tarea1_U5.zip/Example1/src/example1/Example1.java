/*
    Irvin Jair Carrillo Beltran
    Maria Lucia Barron Estrada
    Programacion Orientada a Objetos
    10-11Am
*/
package example1;
import java.util.Scanner;
public class Example1 {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Ejemplo uno");
        try {
            int num1;
            int num2;
            int suma;
            System.out.println("Ingresa el valor de un numero");
            num1=leer.nextInt();
            System.out.println("Ingresa el valor de otro numero");
            num2=leer.nextInt();
            suma=num1/num2;
        } catch (ArithmeticException e) {
            System.out.println("No es posible hacer la operacion");
        }
        /*
        La excepcion va a ocurrir cuando se tenga una division entre cero,
        porque una division entre cero no esta definido en las matematicas
        */
        
        System.out.println("\nEjemplo dos");
        try {
            int a[] = new int [10];
            a[11]=5;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayindexOutOfBounds");
        }
            /*
        La excepcion sucede cuando quieren acceder a un campo de un arreglo
        donde no esta lo suficiente extenso(no existe)
        */
        
        
            System.out.println("\nEjemplo 3");
            
        try {
            int num = Integer.parseInt("XYZ");//Solucion ("numeros(5,6,7)")
            System.out.println(num);
        } catch (NumberFormatException e) {
            System.out.println("Excepcion en el formato del numero");
        }
        /*
        La excepcion ocurre cuando quiere convertir una cadena(String) 
        de caracteres a int, en el cual no hay ningun numero en esa
        cadena(String) con lo cual no puede convertirse
        */
        
        System.out.println("\nEjemplo 4 ");
        try {
            String str = "beginnersbook";
            System.out.println(str.length());
            char c = str.charAt(0);
            c = str.charAt(40);
            System.out.println(c);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("StringIndexOutOfBoundsException");
        }
        /*
        La excepcion se da porque la varible c de tipo char intenta obtener
        un valor que no existe en el String
        */
    }
    
}
